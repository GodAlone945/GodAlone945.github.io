<template>
  <div>
    <Main :propData="initData"/>
  </div>
</template>

<script>
import Main from './components/Main'
export default {
  data () {
    return {
      initData: '2021-7-12',
    }
  },
  components: {
    Main
  }
}
</script>

<style>
</style>
