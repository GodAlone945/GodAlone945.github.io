<template>
  <div class="container">
    <div>{{msg}}</div>
    <div>{{propData}}</div>
  </div>
</template>

<script>
export default {
  name: 'test',
  data () {
    return {
      msg: 'GodAlone945'
    }
  },
  props: {
    propData: {
      type: String,
      default: '1998-4-5'
    }
  }
}
</script>

<style>
.container{
  text-align: center;
}
</style>
