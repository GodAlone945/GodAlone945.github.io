window.onload = function () {
    const body = document.body.clientWidth
    // 下载安装包
    // if (body > 441) {
    //   window.location.href = 'http://zhfb.fenbanruanjian.com/source/mysetup.exe'
    // }

    let second = 5
    // 获取下载提示弹窗
    const dialog = $('#dialog')
    // 弹窗关闭倒计时
    const time = $('#time')
    // 我知道了按钮
    const btn = $('#btn')
    // 获取头部导航栏各按钮dom
    const liDom = $('.nav>li a')
    const navBtn = $('.nav_btn')
    const closeBtn = $('.nav-close_btn')
    // 获取立即下载按钮
    const downLoad = $('.row_four')
    // 小屏幕下，下载安装包点击
    const downExe = $('.row_six')
    // 小屏幕下，微信关注公众号使用
    const weixin = $('.row_five')
    // 关注公众号，二维码提示
    const popup = $('#popup')
    const wDialog = $('.w_dialog')
    const closeW = $('#closeW')
    const dDialog = $('.d_dialog')
    const contentD = $('#content_d')

    closeW.click(function () {
        wDialog.addClass('none')
    })

    weixin.click(function () {
        wDialog.removeClass('none')
        popup.removeClass('none')
    })

    downLoad.click(function () {
        // window.location.href = 'http://zhfb.fenbanruanjian.com/source/mysetup.exe'
    })

    downExe.click(function () {
        var ua = window.navigator.userAgent.toLowerCase();//判断网页是否由微信浏览器打开

        if (ua.match(/MicroMessenger/i) == 'micromessenger') { //如果是则下载该
            dDialog.removeClass('none')
        } else {
            // window.location.href = 'http://zhfb.fenbanruanjian.com/source/mysetup.exe';//下载地址
        }
    })

    contentD.click(function () {
        dDialog.addClass('none')
    })

    navBtn.click(function () {
        navBtn.hide()
        closeBtn.show()

        $(".main-nav").slideDown(400);
        $('body,html').css('overflow','hidden')
    })
    closeBtn.click(function () {
        closeBtn.hide()
        navBtn.show()

        $(".main-nav").slideUp(300);
    })

    // 当点击导航栏标签时，先移除所有的标签active样式，在对点击的那个标签添加active样式
    liDom.click(function (e) {
        $.makeArray(liDom).forEach((e, i) => {
            $(e).removeClass('active')
        })
        $(e.target).addClass('active')
    })

    // 下载时，显示提示弹窗
    if (body > 441) {
        dialog.removeClass('none')
    }
    let timeFive = setInterval(() => {
        second -= 1
        time.text(second)
    }, 1000)
    setTimeout(function () {
        clearInterval(timeFive)
        dialog.addClass('none')
    }, 5000)

    btn.click(function () {
        clearInterval(timeFive)
        dialog.addClass('none')
    })
}
// 点击三条线
var  navTab =document.querySelector('.nav-tab')
// 三条线
var  navTabs =document.querySelector('.nav-tab-sub')
// X线
var  navTabx =document.querySelector('.nav_tab_x')
// 一级菜单页面
var mainNav =document.querySelector('.main-nav')
//一级菜单
var mainTitle =document.querySelectorAll('.main-nav_title')
//二级菜单
var mainShow =document.querySelectorAll('.nav-show')
// 正方形点击
navTabs.onclick=function(){
    navTabs.style.display="none"
    navTabx.style.display="block"
    // mainNav.style.display="block"

    $(".main-nav").slideDown(400);
    // $('.nav-tab').css('background','#223fa8')
    $('body,html').css('overflow','hidden')

}

//叉号点击
navTabx.onclick=function(){

    navTabx.style.display="none"
    navTabs.style.display="block"
    // mainNav.style.display="none"
    $(".main-nav").slideUp(300);
    // $('.nav-tab').css('background','0')
    $('body,html').css('overflow','auto')
}

// 屏幕大于756
window.onresize = function () {
    if(document.body.clientWidth >= 768){
        $(".main-nav").css("display","none");
        navTabx.style.display="none"
        navTabs.style.display="block"
    }
}

//导航栏滚动固定
window.addEventListener('scroll', function(){
    let t = $('body, html').scrollTop();   // 目前监听的是整个body的滚动条距离
    if(t>720){
        $('.header-navigation').addClass('header-nav')
    }else{
        $('.header-navigation').removeClass('header-nav')
    }
})
